## Запуск

```
cd infra
docker compose up -d --build
```