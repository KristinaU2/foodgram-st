from rest_framework import serializers
from recipes.models import (
    Ingredient,
    Recipe,
    RecipeIngredient,
)
from drf_extra_fields.fields import Base64ImageField


class RecipeMiniSerializer(serializers.ModelSerializer):
    """
    Упрощенный сериализатор рецептов.
    """
    image = serializers.SerializerMethodField()

    class Meta:
        model = Recipe
        fields = ('id', 'name', 'image', 'cooking_time')

    def get_image(self, obj):
        if obj.image:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.image.url)
            return obj.image.url
        return ""


class IngredientSerializer(serializers.ModelSerializer):
    """Сериализатор для отображения ингредиентов."""

    class Meta:
        model = Ingredient
        fields = ['id', 'name', 'measurement_unit']


class RecipeIngredientSerializer(serializers.ModelSerializer):
    """Сериализатор для отображения ингредиентов внутри рецепта."""
    id = serializers.PrimaryKeyRelatedField(
        queryset=Ingredient.objects.all(), source='ingredient'
    )
    name = serializers.ReadOnlyField(source='ingredient.name')
    measurement_unit = serializers.ReadOnlyField(source='ingredient.measurement_unit')

    class Meta:
        model = RecipeIngredient
        fields = ['id', 'name', 'measurement_unit', 'amount']


class RecipeReadSerializer(serializers.ModelSerializer):
    """Сериализатор для чтения рецептов."""
    author = serializers.SerializerMethodField()
    ingredients = serializers.SerializerMethodField()
    image = serializers.SerializerMethodField()
    is_favorited = serializers.SerializerMethodField()
    is_in_shopping_cart = serializers.SerializerMethodField()

    class Meta:
        model = Recipe
        fields = [
            'id', 'author', 'name', 'image', 'text',
            'ingredients', 'cooking_time',
            'is_favorited', 'is_in_shopping_cart'
        ]

    def get_image(self, obj):
        if obj.image:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.image.url)
            return obj.image.url
        return ""

    def get_ingredients(self, obj):
        ingredients = RecipeIngredient.objects.filter(recipe=obj)
        return RecipeIngredientSerializer(ingredients, many=True).data

    def get_author(self, obj):
        from users.serializers import UserSerializer
        return UserSerializer(obj.author, context=self.context).data

    def get_is_favorited(self, obj):
        request = self.context.get('request')
        if not request or request.user.is_anonymous:
            return False
        return obj.favorited_by.filter(user=request.user).exists()

    def get_is_in_shopping_cart(self, obj):
        request = self.context.get('request')
        if not request or request.user.is_anonymous:
            return False
        return obj.in_shopping_cart.filter(user=request.user).exists()


class RecipeWriteSerializer(serializers.ModelSerializer):
    """Сериализатор для создания и обновления рецептов."""
    ingredients = RecipeIngredientSerializer(many=True)
    image = Base64ImageField()

    class Meta:
        model = Recipe
        fields = [
            'id', 'name', 'image', 'text', 'ingredients', 'cooking_time'
        ]

    def validate_name(self, value):
        if not value or not value.strip():
            raise serializers.ValidationError('Это поле не может быть пустым.')
        return value

    def validate_text(self, value):
        if not value or not value.strip():
            raise serializers.ValidationError('Это поле не может быть пустым.')
        return value

    def validate_image(self, value):
        if not value:
            raise serializers.ValidationError('Это поле обязательно.')
        return value

    def validate_cooking_time(self, value):
        if value is None:
            raise serializers.ValidationError('Это поле обязательно.')
        if value < 1:
            raise serializers.ValidationError('Время приготовления должно быть больше 0.')
        return value

    def validate_ingredients(self, value):
        if not value:
            raise serializers.ValidationError('Нужно выбрать хотя бы один ингредиент.')
        seen = set()
        for item in value:
            ingredient_id = item['ingredient'].id
            if ingredient_id in seen:
                raise serializers.ValidationError('Ингредиенты должны быть уникальными.')
            seen.add(ingredient_id)
            
            amount = item.get('amount')
            if amount is None or amount < 1:
                raise serializers.ValidationError('Количество ингредиента должно быть больше 0.')
        return value

    def validate(self, data):
        """Общая валидация для всех полей."""

        if self.instance and 'ingredients' not in data:
            raise serializers.ValidationError({'ingredients': ['Это поле обязательно.']})

        if 'image' in data and not data['image']:
            raise serializers.ValidationError({'image': ['Это поле не может быть пустым.']})
            
        return data

    def create_ingredients(self, recipe, ingredients):
        RecipeIngredient.objects.bulk_create([
            RecipeIngredient(
                recipe=recipe,
                ingredient=ingredient['ingredient'],
                amount=ingredient['amount']
            ) for ingredient in ingredients
        ])

    def create(self, validated_data):
        ingredients = validated_data.pop('ingredients')
        recipe = Recipe.objects.create(**validated_data)
        self.create_ingredients(recipe, ingredients)
        return recipe

    def update(self, instance, validated_data):
        ingredients = validated_data.pop('ingredients', None)

        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()

        if ingredients is not None:
            instance.ingredients.clear()
            self.create_ingredients(instance, ingredients)

        return instance

    def to_representation(self, instance):
        return RecipeReadSerializer(instance, context=self.context).data


class FavoriteSerializer(serializers.ModelSerializer):
    """Сериализатор для избранного"""

    class Meta:
        model = Recipe
        fields = ['id', 'name', 'image', 'cooking_time']

    def to_representation(self, instance):
        if hasattr(instance, 'recipe'):
            recipe = instance.recipe
        else:
            recipe = instance
        
        return {
            'id': recipe.id,
            'name': recipe.name,
            'image': self.get_image_url(recipe),
            'cooking_time': recipe.cooking_time
        }

    def get_image_url(self, recipe):
        if recipe.image:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(recipe.image.url)
            return recipe.image.url
        return ""


class ShoppingCartSerializer(serializers.ModelSerializer):
    """Сериализатор для корзины: возвращает данные рецепта напрямую."""

    class Meta:
        model = Recipe
        fields = ['id', 'name', 'image', 'cooking_time']

    def to_representation(self, instance):
        if hasattr(instance, 'recipe'):
            recipe = instance.recipe
        else:
            recipe = instance
            
        return {
            'id': recipe.id,
            'name': recipe.name,
            'image': self.get_image_url(recipe),
            'cooking_time': recipe.cooking_time
        }

    def get_image_url(self, recipe):
        if recipe.image:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(recipe.image.url)
            return recipe.image.url
        return ""