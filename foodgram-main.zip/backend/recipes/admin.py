from django.contrib import admin
from recipes.models import (
    Ingredient, Recipe, RecipeIngredient,
    Favorite, ShoppingCart
)


class IngredientInline(admin.TabularInline):
    """
    Встроенная модель ингредиентов - для отображения в рецепте.
    """
    model = RecipeIngredient
    extra = 1


@admin.register(Recipe)
class RecipeAdmin(admin.ModelAdmin):
    """Админка для рецептов"""
    list_display = ('id', 'name', 'author', 'cooking_time', 'favorites_count')
    list_filter = ('author',)
    search_fields = ('name', 'author__username')
    inlines = [IngredientInline]

    def favorites_count(self, obj):
        return obj.favorited_by.count()
    favorites_count.short_description = 'В избранном у'


@admin.register(Ingredient)
class IngredientAdmin(admin.ModelAdmin):
    """Админка для ингредиентов"""
    list_display = ('id', 'name', 'measurement_unit')
    search_fields = ('name',)


@admin.register(Favorite)
class FavoriteAdmin(admin.ModelAdmin):
    """Админка для избранного"""
    list_display = ('id', 'user', 'recipe')
    list_filter = ('user',)


@admin.register(ShoppingCart)
class ShoppingCartAdmin(admin.ModelAdmin):
    """Админка для корзины покупок"""
    list_display = ('id', 'user', 'recipe')
    list_filter = ('user',)