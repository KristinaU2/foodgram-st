import csv
import json
from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from recipes.models import Ingredient


class Command(BaseCommand):
    help = 'Импортирует ингредиенты из файлов data/ingredients.csv или data/ingredients.json'

    def add_arguments(self, parser):
        parser.add_argument(
            '--file',
            type=str,
            help='Путь к файлу с ингредиентами (CSV или JSON)',
        )
        parser.add_argument(
            '--format',
            type=str,
            choices=['csv', 'json'],
            help='Формат файла (csv или json). Если не указан, определяется автоматически по расширению',
        )
        parser.add_argument(
            '--clear',
            action='store_true',
            help='Очистить существующие ингредиенты перед загрузкой',
        )

    def handle(self, *args, **kwargs):
        file_path = kwargs.get('file')
        file_format = kwargs.get('format')
        clear_existing = kwargs.get('clear')

        if not file_path:
            base_dir = Path(settings.BASE_DIR) / 'data'

            csv_path = base_dir / 'ingredients.csv'
            json_path = base_dir / 'ingredients.json'
            
            if csv_path.exists():
                file_path = csv_path
                file_format = 'csv'
                self.stdout.write(f'Найден файл: {file_path}')
            elif json_path.exists():
                file_path = json_path
                file_format = 'json'
                self.stdout.write(f'Найден файл: {file_path}')
            else:
                raise CommandError(f'Файлы ingredients.csv или ingredients.json не найдены в {base_dir}')
        else:
            file_path = Path(file_path)

        if not file_path.exists():
            raise CommandError(f'Файл не найден: {file_path}')

        if not file_format:
            if file_path.suffix.lower() == '.csv':
                file_format = 'csv'
            elif file_path.suffix.lower() == '.json':
                file_format = 'json'
            else:
                raise CommandError('Не удалось определить формат файла. Укажите --format csv или --format json')

        if clear_existing:
            deleted_count = Ingredient.objects.count()
            Ingredient.objects.all().delete()
            self.stdout.write(
                self.style.WARNING(f'Удалено {deleted_count} существующих ингредиентов')
            )

        if file_format == 'csv':
            count = self._load_from_csv(file_path)
        elif file_format == 'json':
            count = self._load_from_json(file_path)
        else:
            raise CommandError(f'Неподдерживаемый формат: {file_format}')

        self.stdout.write(
            self.style.SUCCESS(f'Успешно импортировано {count} ингредиентов из {file_path}')
        )

    def _load_from_csv(self, file_path):
        """Загружает ингредиенты из CSV файла."""
        count = 0
        
        with open(file_path, newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            
            for row_num, row in enumerate(reader, 1):
                if len(row) < 2:
                    self.stdout.write(
                        self.style.WARNING(f'Строка {row_num}: недостаточно данных - {row}')
                    )
                    continue
                
                name = row[0].strip()
                unit = row[1].strip()
                
                if not name or not unit:
                    self.stdout.write(
                        self.style.WARNING(f'Строка {row_num}: пустые данные - {row}')
                    )
                    continue
                
                ingredient, created = Ingredient.objects.get_or_create(
                    name=name,
                    measurement_unit=unit
                )
                
                if created:
                    count += 1
                    self.stdout.write(f'+ {name} ({unit})')
                else:
                    self.stdout.write(f'= {name} ({unit}) - уже существует')
        
        return count

    def _load_from_json(self, file_path):
        """Загружает ингредиенты из JSON файла."""
        count = 0
        
        try:
            with open(file_path, 'r', encoding='utf-8') as jsonfile:
                data = json.load(jsonfile)
        except json.JSONDecodeError as e:
            raise CommandError(f'Ошибка при чтении JSON файла: {e}')
        
        if not isinstance(data, list):
            raise CommandError('JSON файл должен содержать массив объектов')
        
        for item_num, item in enumerate(data, 1):
            if not isinstance(item, dict):
                self.stdout.write(
                    self.style.WARNING(f'Элемент {item_num}: не является объектом - {item}')
                )
                continue
            
            name = item.get('name', '').strip()
            unit = item.get('measurement_unit', '').strip()
            
            if not name or not unit:
                self.stdout.write(
                    self.style.WARNING(f'Элемент {item_num}: отсутствуют обязательные поля - {item}')
                )
                continue
            
            ingredient, created = Ingredient.objects.get_or_create(
                name=name,
                measurement_unit=unit
            )
            
            if created:
                count += 1
                self.stdout.write(f'+ {name} ({unit})')
            else:
                self.stdout.write(f'= {name} ({unit}) - уже существует')
        
        return count