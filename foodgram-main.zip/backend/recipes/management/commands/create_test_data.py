from django.core.management.base import BaseCommand
from django.core.files.base import ContentFile
import base64

from users.models import User
from recipes.models import Ingredient, Recipe, RecipeIngredient


class Command(BaseCommand):
    help = 'Создание тестовых данных: пользователи и рецепты'

    def handle(self, *args, **options):
        try:
            self.stdout.write("Создание тестовых данных...")

            self.create_superuser()
            users = self.create_test_users()
            ingredients = self.get_ingredients()
            recipes = self.create_test_recipes(users, ingredients)

            self.stdout.write(
                self.style.SUCCESS(
                    f'\nВсего создано:\n'
                    f'Пользователей: {len(users)}\n'
                    f'Рецептов: {len(recipes)}\n'
                    f'Тестовые данные успешно созданы!'
                )
            )
        except Exception as e:
            self.stdout.write(
                self.style.ERROR(f'Ошибка при создании тестовых данных: {e}')
            )
            raise

    def create_superuser(self):
        email = 'admin@admin.com'
        username = 'admin'
        password = 'admin'

        if not User.objects.filter(email=email).exists():
            User.objects.create_superuser(
                email=email,
                username=username,
                password=password,
                first_name='admin',
                last_name='admin'
            )
            self.stdout.write(self.style.SUCCESS(f"Создан суперпользователь: {email} / {password}"))
        else:
            self.stdout.write(f"Суперпользователь уже существует: {email}")

    def create_test_users(self):
        users_data = [
            {
                'email': 'test1@example.com',
                'username': 'testuser1',
                'first_name': 'Иван',
                'last_name': 'Петров',
                'password': 'testpassword123'
            },
            {
                'email': 'test2@example.com',
                'username': 'testuser2',
                'first_name': 'Мария',
                'last_name': 'Сидорова',
                'password': 'testpassword123'
            }
        ]
        
        created_users = []
        for user_data in users_data:
            user, created = User.objects.get_or_create(
                email=user_data['email'],
                defaults={
                    'username': user_data['username'],
                    'first_name': user_data['first_name'],
                    'last_name': user_data['last_name']
                }
            )
            if created:
                user.set_password(user_data['password'])
                user.save()
                self.stdout.write(f"Создан пользователь: {user.email}")
            else:
                self.stdout.write(f"Пользователь уже существует: {user.email}")
            created_users.append(user)
        
        return created_users

    def get_ingredients(self):
        ingredients_names = [
            'мука пшеничная', 'молоко', 'яйцо куриное', 'сахар', 'соль', 
            'масло подсолнечное', 'помидор', 'лук репчатый', 'чеснок', 
            'сыр', 'курица', 'рис', 'морковь', 'картофель', 'перец черный'
        ]
        
        ingredients = []
        for name in ingredients_names:
            try:
                ingredient = Ingredient.objects.filter(name__icontains=name).first()
                if ingredient:
                    ingredients.append(ingredient)
            except Exception as e:
                self.stdout.write(f"Ошибка при поиске ингредиента '{name}': {e}")
        
        if len(ingredients) < 5:

            fallback_ingredients = list(Ingredient.objects.all()[:10])
            ingredients.extend(fallback_ingredients)
            ingredients = ingredients[:10]
        
        return ingredients

    def create_test_image(self, recipe_index):
        import os
        from django.conf import settings

        image_paths = [
            os.path.join(settings.BASE_DIR, 'media', 'recipes', 'recipe1.jpg'),
            os.path.join(settings.BASE_DIR, 'media', 'recipes', 'recipe2.jpg'),
        ]

        if recipe_index < len(image_paths):
            path = image_paths[recipe_index]
            if os.path.exists(path):
                with open(path, 'rb') as f:
                    filename = f'recipe_{recipe_index + 1}_{os.path.basename(path)}'
                    return ContentFile(f.read(), name=filename)

        png_data = base64.b64decode(
            'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8/5+hHgAHggJ/PchI7wAAAABJRU5ErkJggg=='
        )
        return ContentFile(png_data, name=f'test_recipe_{recipe_index + 1}.png')

    def create_test_recipes(self, users, ingredients):
        if len(ingredients) < 8:
            self.stdout.write(
                self.style.WARNING('Недостаточно ингредиентов для создания рецептов. Импортируйте ингредиенты сначала.')
            )
            return []

        recipes_data = [
            {
                'name': 'Блинчики на молоке',
                'text': 'Классические блинчики на молоке. Смешиваем муку, молоко, яйца и сахар. Жарим на сковороде до золотистого цвета.',
                'cooking_time': 30,
                'ingredients_indices': [0, 1, 2, 3, 4, 5],
                'amounts': [200, 300, 2, 30, 5, 20]
            },
            {
                'name': 'Простая яичница',
                'text': 'Быстрая и вкусная яичница с луком. Обжариваем лук, добавляем яйца и готовим до нужной консистенции.',
                'cooking_time': 15,
                'ingredients_indices': [2, 7, 4, 5],
                'amounts': [3, 1, 3, 10]
            }
        ]
        
        created_recipes = []
        for i, recipe_data in enumerate(recipes_data):
            author = users[i % len(users)]
            
            recipe, created = Recipe.objects.get_or_create(
                name=recipe_data['name'],
                author=author,
                defaults={
                    'text': recipe_data['text'],
                    'cooking_time': recipe_data['cooking_time'],
                    'image': self.create_test_image(i)
                }
            )
            
            if created:
                self.stdout.write(f"Создан рецепт: {recipe.name} (автор: {author.first_name})")
                
                for j, ingredient_index in enumerate(recipe_data['ingredients_indices']):
                    if ingredient_index < len(ingredients):
                        RecipeIngredient.objects.get_or_create(
                            recipe=recipe,
                            ingredient=ingredients[ingredient_index],
                            defaults={'amount': recipe_data['amounts'][j]}
                        )
            else:
                self.stdout.write(f"Рецепт уже существует: {recipe.name}")

                if not recipe.image:
                    recipe.image = self.create_test_image(i)
                    recipe.save()
            
            created_recipes.append(recipe)
        
        return created_recipes