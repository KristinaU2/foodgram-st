from rest_framework import permissions


class IsAuthenticatedForMe(permissions.BasePermission):
    """
    Разрешение для эндпоинта me.
    """

    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated
