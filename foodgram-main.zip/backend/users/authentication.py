from rest_framework.authentication import TokenAuthentication
from rest_framework import exceptions
from django.contrib.auth.models import AnonymousUser


class CustomTokenAuthentication(TokenAuthentication):
    """
    Кастомная токен-аутентификация, которая не блокирует запросы с невалидными токенами.
    Если токен невалидный, пользователь считается анонимным.
    """

    def authenticate(self, request):
        try:
            return super().authenticate(request)
        except exceptions.AuthenticationFailed:

            return None
